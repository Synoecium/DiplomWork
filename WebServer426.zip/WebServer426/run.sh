#!/bin/bash

BASEDIR=$(dirname "$0")
node "$BASEDIR"/cirrus %*
