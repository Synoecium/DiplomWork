#!/bin/bash

PublicIp="$(wget -qO- https://ipecho.net/plain)"
echo "Public IP: $PublicIp"

#peerConnectionOptions="{ \""iceServers\"": [{\""urls\"": [\""stun:$PublicIp:19302\""]}] }"
peerConnectionOptions="{ \""iceServers\"": [{\""urls\"": [\""stun:stun.l.google.com:19302\"",\""turn:$PublicIp:19303\""], \""username\"": \""PixelStreamingUser\"", \""credential\"": \""Another_TURN_in_the_road\""}] }"
echo "peerConnectionOptions: $peerConnectionOptions"

BASEDIR=$(dirname "$0")

node "$BASEDIR"/cirrus --peerConnectionOptions="$peerConnectionOptions" --publicIp=$PublicIp
#%*


